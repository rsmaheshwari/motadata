package com.crud.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.core.KafkaTemplate;

import com.crud.exception.ResourceNotFoundException;
import com.crud.model.Audit;
import com.crud.model.Employee;
import com.crud.repository.AuditRepository;
import com.crud.repository.EmployeeRepository;
import com.crud.util.Util;

@ExtendWith(MockitoExtension.class)
public class EmployeeServiceImplTest {

	@Mock
	private EmployeeRepository repo;

	@Mock
	private AuditRepository auditRepo;

	@Mock
	private KafkaTemplate<String, String> kafkaTemplate;

	@Mock
	private Util util;

	@InjectMocks
	private EmployeeServiceImpl employeeService;

	private Employee employee;
	private Audit audit;

	@BeforeEach
	public void setUp() {
		// Setting up an example Employee and Audit object
		employee = new Employee();
		employee.setEmpId(1);
		employee.setName("John Doe");

		audit = new Audit("CREATE", "Save operation with id - 1");

		// Mocking the Util class for conversion
		lenient().when(util.objectToJson(any(Audit.class)))
				.thenReturn("{\"action\":\"CREATE\",\"description\":\"Save operation with id - 1\"}");

	}

	@Test
	public void testCreateEmployee() {
		// Mocking the repository save call
		when(repo.save(any(Employee.class))).thenReturn(employee);

		// Act: Call the service method
		Integer id = employeeService.createEmployee(employee);

		// Assert
		assertEquals(1, id);
		verify(repo, times(1)).save(employee);
	}

	@Test
	public void testGetEmployeeById() {
		// Mock the repository findById method
		when(repo.findById(1)).thenReturn(Optional.of(employee));

		// Act: Call the service method
		Employee result = employeeService.getEmployeeById(1);

		// Assert
		assertNotNull(result);
		assertEquals(employee.getEmpId(), result.getEmpId());
		verify(repo, times(1)).findById(1);
	}

	@Test
	public void testUpdateEmployee() {
		// Mock the repository calls
		when(repo.findById(1)).thenReturn(Optional.of(employee));
		when(repo.save(any(Employee.class))).thenReturn(employee);

		// Act: Call the service method
		Employee updatedEmployee = employeeService.updateEmployee(employee);

		// Assert
		assertNotNull(updatedEmployee);
		verify(repo, times(1)).findById(1);
		verify(repo, times(1)).save(employee);
	}

	@Test
	public void testDeleteEmployeeById() {
		// Mock the repository find and delete methods
		when(repo.findById(1)).thenReturn(Optional.of(employee));

		// Act: Call the service method
		Integer deletedId = employeeService.deleteEmployeeById(1);

		// Assert
		assertEquals(1, deletedId);
		verify(repo, times(1)).findById(1);
		verify(repo, times(1)).deleteById(1);
	}

	@Test
	public void testGetEmployeeById_NotFound() {
		// Mock the repository findById method to return empty
		when(repo.findById(1)).thenReturn(Optional.empty());

		// Act & Assert: Call the service method and expect an exception
		assertThrows(ResourceNotFoundException.class, () -> employeeService.getEmployeeById(1));
		verify(repo, times(1)).findById(1);
	}
}
