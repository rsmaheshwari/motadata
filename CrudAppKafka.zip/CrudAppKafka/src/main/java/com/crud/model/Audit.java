package com.crud.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "audit")
public class Audit {

	@Id
	@GeneratedValue
	@Column(name = "Log Id")
	private Integer id;

	@Column(name = "Operation")
	private String operation;

	@Column(name = "Log")
	private String log;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getOperation() {
		return operation;
	}

	public void setOperation(String operation) {
		this.operation = operation;
	}

	public String getLog() {
		return log;
	}

	public void setLog(String log) {
		this.log = log;
	}

	public Audit( String operation, String log) {
		this.operation = operation;
		this.log = log;
	}

	public Audit() {
		super();
	}

	@Override
	public String toString() {
		return "Audit [id=" + id + ", operation=" + operation + ", log=" + log + "]";
	}

	
}
