package com.crud.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.crud.model.Employee;
import com.crud.service.EmployeeServiceImpl;

/**
 * This is a Employee Controller class
 * 
 */
@RestController
@RequestMapping("/employee")
public class EmployeeController {

	private EmployeeServiceImpl service;

	
	public EmployeeController(EmployeeServiceImpl service) {
		this.service = service;
	}

	
	/**
	 * This method will perform creation of employee.
	 * @param employee
	 * @return String
	 */
	@PostMapping("/create")
	public ResponseEntity<String> createEmployee(@RequestBody Employee e) {
		return new ResponseEntity<>("Employee Created Successfully, Id - " + service.createEmployee(e),
				HttpStatus.CREATED);
	}

	/**
	 * This method will perform read operation of employee.
	 * @param id
	 * @return Employee
	 */
	@GetMapping("/getById")
	public ResponseEntity<Employee> getEmployeeById(Integer id) {
		return new ResponseEntity<>(service.getEmployeeById(id), HttpStatus.FOUND);
	}

	/**
	 * This method will perform update operation of employee.
	 * @param Employee
	 * @return String
	 */
	@PutMapping("/update")
	public ResponseEntity<String> updateEmployee(@RequestBody Employee e) {
		return new ResponseEntity<>("Employee Updated Successfully " + service.updateEmployee(e).toString(),
				HttpStatus.OK);
	}

	/**
	 * This method will perform delete operation of employee.
	 * @param Employee id
	 * @return String
	 */
	@DeleteMapping("/delete")
	public ResponseEntity<String> deleteEmployeeById(Integer id) {
		return new ResponseEntity<>("Employee deleted id - " + service.deleteEmployeeById(id), HttpStatus.OK);
	}

}
