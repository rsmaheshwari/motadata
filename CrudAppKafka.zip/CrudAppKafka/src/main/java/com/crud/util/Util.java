package com.crud.util;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class Util {

	//for producing the data in kafka
	public String objectToJson(Object o) {
		String jsonData = "";
		ObjectMapper m = new ObjectMapper();
		try {
			jsonData = m.writeValueAsString(o);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}

		return jsonData;
	}
	
	//for consuming the string data
	public Object jsonToObject(String message, Object o) {

		ObjectMapper mapper = new ObjectMapper();
		Object obj = new Object();
		try {
			obj = mapper.readValue(message, o.getClass());
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		} 

		return obj;
	}
	
}
