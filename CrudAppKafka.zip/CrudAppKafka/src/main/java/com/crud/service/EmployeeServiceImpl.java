package com.crud.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.crud.exception.ResourceNotFoundException;
import com.crud.model.Audit;
import com.crud.model.Employee;
import com.crud.repository.AuditRepository;
import com.crud.repository.EmployeeRepository;

import jakarta.transaction.Transactional;

/**
 * This is a Employee Service class
 * 
 */
@Service
public class EmployeeServiceImpl implements EmployeeService {

	private EmployeeRepository repo;
	private AuditRepository auditRepo;
	private com.crud.util.Util util;
	private KafkaTemplate<String, String> kafkaTemplate;

	@Value("${com.employee.topic}") String topic;


	/**
	 * @param Employee repo
	 * @param Audit repo
	 * @param Kafka template
	 * @param util
	 */
	public EmployeeServiceImpl(EmployeeRepository repo, AuditRepository auditrepo,
			KafkaTemplate<String, String> template, com.crud.util.Util util) {
		this.repo = repo;
		this.kafkaTemplate = template;
		this.auditRepo = auditrepo;
		this.util = util;
	}

	/**
	 * This method will send data to subscriber
	 * @param message
	 */
	public void sendData(String message) {
		kafkaTemplate.send(topic, message);
	}

	/**
	 * This method will read data from publisher
	 * @param message
	 */
	@KafkaListener(topics = "${com.employee.topic}", groupId = "allClients")
	public void getData(String message) {

		Audit log = (Audit) util.jsonToObject(message, new Audit());
		auditRepo.save(log);
	}

	
	
	/**
	 * This method will create employee
	 *@param Employee
	 *@return Id
	 */
	@Override
	@Transactional
	public Integer createEmployee(Employee e) {
		Integer id = repo.save(e).getEmpId();
		sendData(util.objectToJson(new Audit("CREATE", "Save operation with id - " + id)));
		return id;
	}

	/**
	 * This method will fetch employee by id
	 *@param Id
	 *@return Employee
	 */
	@Override
	public Employee getEmployeeById(Integer id) {
		Employee emp = repo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not found with ID: " + id));
		sendData(util.objectToJson(new Audit("READ", "Read operation with id -" + id)));
		return emp;
	}

	
	/**
	 * This method will update employee
	 *@param Employee
	 *@return Employee
	 */
	@Override
	@Transactional
	public Employee updateEmployee(Employee e) {

		Employee existingEmployee = getEmployeeById(e.getEmpId());
		existingEmployee.setName(e.getName());
		Employee updatedEmp = repo.save(e);
		sendData(util.objectToJson(new Audit("UPDATE", "UPDATE operation with id -" + updatedEmp.getEmpId())));
		return updatedEmp;
	}

	/**
	 *This method will delete employee
	 *@param Id
	 *@return Id
	 */
	@Override
	@Transactional
	public Integer deleteEmployeeById(Integer id) {
		getEmployeeById(id);
		repo.deleteById(id);
		sendData(util.objectToJson(new Audit("DELETE", "Read operation with id -" + id)));
		return id;
	}

}
