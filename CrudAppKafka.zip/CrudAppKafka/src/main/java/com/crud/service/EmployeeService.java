package com.crud.service;

import com.crud.model.Employee;

public interface EmployeeService {
	
	Integer createEmployee(Employee e);
	Employee getEmployeeById(Integer id);
	Employee updateEmployee(Employee e);
	Integer deleteEmployeeById(Integer id);

}
